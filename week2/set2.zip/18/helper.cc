
#include <iostream>
#include <string>

using namespace std;

int main(int argc, char **argv)
{
    int var = stoi(argv[0]);
    cout << var;
}