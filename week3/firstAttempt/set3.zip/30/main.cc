#include "main.ih"

int main(int argc, char *argv[])
{
    callValue(argv[0]);
    callRef(argv[0]);
}

