#include "main.ih"

void fun(string s)
{
    size_t sum = 0;
    for (size_t idx = 0; idx < s.length(); ++idx)
        sum += s[idx];
}