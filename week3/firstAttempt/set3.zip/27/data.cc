#include "main.ih"

//global variables
size_t nTotal = 0;
size_t nRequired = 0;