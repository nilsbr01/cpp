#include "main.ih"

int main(int argc, char **argv)
try
{
    bool sCall = structCall(argc, argv);
    
    bool bCall = boundCall(argc, argv);
        
}
catch (...)
{
    return 1;
}
