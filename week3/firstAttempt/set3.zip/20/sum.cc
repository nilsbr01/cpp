int sum(int value1, int value2)     // function if parameters are integrals
{
    return value1 + value2;
}

double sum(double value1, double value2)        // function if parameters are doubles
{
    return value1 + value2;
}